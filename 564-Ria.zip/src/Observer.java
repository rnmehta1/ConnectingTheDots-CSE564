/*
Author: Ria Mehta
File Version: 1.0
Time required: 3 hours
*/
interface Observer {
    void update();
}
