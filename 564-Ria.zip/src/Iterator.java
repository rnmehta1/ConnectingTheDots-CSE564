/*
Author: Ria Mehta
File Version: 1.0
Time required: 3 hours
*/
public interface Iterator {
    public boolean hasNext();
    public Object next();
}