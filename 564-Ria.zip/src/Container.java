/*
Author: Ria Mehta
File Version: 1.0
Time required: 3 hours
*/
public interface Container {
    public Iterator getIterator();
}